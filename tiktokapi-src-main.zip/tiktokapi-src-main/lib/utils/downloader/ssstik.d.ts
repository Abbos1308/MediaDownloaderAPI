import { SSSTikResponse } from "../../types/downloader/ssstik";
export declare const SSSTik: (url: string) => Promise<SSSTikResponse>;
