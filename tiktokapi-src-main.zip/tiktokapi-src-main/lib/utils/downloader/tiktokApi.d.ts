import { TiktokAPIResponse } from "../../types/downloader/tiktokApi";
export declare const TiktokAPI: (url: string) => Promise<TiktokAPIResponse>;
