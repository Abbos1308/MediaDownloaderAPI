export declare const _userPostsParams: () => string;
export declare const _userSearchParams: (keyword: any, page?: number) => any;
export declare const _tiktokApiParams: (args: any) => any;
export declare const _xttParams: (secUid: string, cursor: number, count: number) => any;
